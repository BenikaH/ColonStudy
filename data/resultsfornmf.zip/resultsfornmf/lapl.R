library(igraph)
library(MASS)
setwd("/Users/BC/Documents/clinical/")
inWeb <-read.table("InWeb29.txt", header=TRUE, sep="\t") 
g <- matrix(as.numeric(inWeb[,2:(ncol(inWeb)-1)]),nrow=nrow(inWeb))


#g <- as.matrix(inWeb)
graph <-graph.data.frame(inWeb[1:20,], directed=FALSE) 
#graph2 <- graph.edgelist(g)
y <- as.numeric(graph.laplacian(graph, normalized=TRUE, weights=inWeb$Weight[1:20],
                sparse=getIgraphOpt("sparsematrices")))
write.matrix(y.ginv, file="test.txt", sep=" ")

f <- function(m) class(try(solve(y),silent=T))=="matrix"
xt <- matrix(rep(1,25),nc=5)          # singular
yt <- matrix(1+1e-10*rnorm(25),nc=5)  # very nearly singular matrix
zt <- 0.001*diag(1,20) # non-singular, but very smalll determinant

sv <- svd(x)
sv$d
ds <- diag(1/sv$d[1:3])
u <- sv$u
v <- sv$v
us <- as.matrix(u[, 1:ncol(u)])
vs <- as.matrix(v[, 1:ncol(v)])

(y.ginv <- vs %*% ds %*% t(us))
ginv(y)

f(y)
# [1] FALSE
f(ds)
# [1] TRUE
f(y)
# [1] TRUE



x <- matrix(1:9,nrow=3)
y <- c(1,2,3)
y.ginv <- y %*% x
