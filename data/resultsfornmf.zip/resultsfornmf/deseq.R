library(NMF)
library(DESeq2)
library(DESeq)
library(gage)

setwd("/Users/BC/Documents/clinical/")

#####Load in the data######
mi <- as.matrix(read.table("new_matrix_miRNA.txt", header=T,row.names=1, as.is=T))
mi1 <- mi[(1:nrow(mi)-1),];


#####Write matrix to file#####
write.table(norm, file="rpm_matrix_miRNA.txt",row.names=T, sep="\t")

#####Read in new matrix#####
#exprs <- as.matrix(read.table("newly_filtered_matrix.txt", sep="\t",header=TRUE, row.names=1))

#####generate DESeq dataset#####
mode(mi1) <- "integer"

stages <- mi[nrow(mi),];
col.Data <- data.frame(row.names=colnames(mi1), conditions=as.factor(colnames(mi1)))
col.Data <- data.frame(conditions=as.factor(stages))#, condition=factor(c(colnames(mi))))
#row.names=colnames(mi), 
des <- DESeqDataSetFromMatrix(mi1, colData = col.Data, design=~conditions)
des <- DESeqDataSetFromMatrix(mi1, colData = col.Data, design=~1)


des <- DESeq(des)
res <- results(des)
norm <- as.matrix(fpm(des), robust=T)





